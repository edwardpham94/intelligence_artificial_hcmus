from ruleNfact import* 
from knowledgebase import*


global knowlegde
global queries

queries = []
knowlegde = Knowlegde_Base()

def load_Knowlegde_Base(filename:str):
    with open(filename) as file:
        lines = file.readlines()
        for line in lines:
            line = line.strip()
            if  not line.startswith('%') and len(line) > 0 \
            and not line.startswith('not') \
            and not line.startswith('different'):
                if not ':-' in line:
                    fact = Fact(line)
                    knowlegde.addFact(fact)
                else:
                    rule = Rule(line)
                    knowlegde.addRule(rule)

def load_Query(Qfilename: str):
    with open(Qfilename) as q:
        lines = q.readlines()
        for line in lines:
                line = line[line.find('?-')+2:-1].strip('.').strip(' ').replace(' ','')
                if len(line)>0:
                    queries.append(line)
    print("Queries loaded!")
    return queries

def Answer(filename):
    file = open(filename,"w+")
    for query in queries:
        file.write(f"?- {query}.\n")
        temp_fact = Fact(query)
        vars = temp_fact._people()
        count = 0
        for i in vars:
            if isVariable(i):
                count+=1
        if count == 0: #! NO VARIABLE => YES/NO QUESTION
                if knowlegde.TrueFalse(query) == True:
                    file.write("Yes\n")
                else:
                    file.write("No\n")
        else:
            solutions = knowlegde.LookUp(query)
            if solutions == []:
                file.write("No solution\n")
            else:
                for solution in solutions:
                    new_dict = {}
                    for i in range(len(vars)):
                        new_dict[vars[i]] = solution._people()[i]
                        if isVariable(vars[i]):
                            file.write(f"{vars[i]} = {solution._people()[i]}\n")
                    
                
            
            


#! main function:

Fprolog = 'LaterLeDynasty.pl'

load_Knowlegde_Base(Fprolog)
knowlegde.SolveAllRules()
load_Query('LaterLeDynasty_Query.pl')
Answer(f"{Fprolog[:Fprolog.find('.')]}_Answers.txt")
print("Queries have been answered!")

Fprolog = 'KBEngland.pl'

load_Knowlegde_Base(Fprolog)
knowlegde.SolveAllRules()
load_Query('KBE_Questions.pl')
Answer(f"{Fprolog[:Fprolog.find('.')]}_Answers.txt")
print("Queries have been answered!")