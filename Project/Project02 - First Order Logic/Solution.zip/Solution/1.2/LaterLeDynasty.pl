%! Utilities
% % % % % % % % % % % % % % % % % % % % % % %
not(P) :- P, !P, fail , true.
different(X, Y) :- X = Y, !, fail ; true.
% % % % % % % % % % % % % % % % % % % % % % %

%! Relationships
% % % % % % % % % % % % % % % % % % % % % % %
con(X,Y):- cha(Y,X).

con(X,Y):- cha(Z,X), vo_chong(Z,Y).

hoang_tu(X):- con(X,Y), vua(Y).

hoang_hau(X):- vo_chong(Z,X), vua(Z).

thai_thuong_hoang(X):- vua(X), vua(Y), cha(X,Y).

ong(X,Z):- cha(X,Y), cha(Y,Z).

chau_noi(X,Z):- ong(Z,X).

quoc_lao(X):- not(vua(X)), cha(X,Y), vua(Y).

anh_em_ruot(X,Y):- cha(Z,Y), cha(Z,X), different(X,Y).

chu_hoac_bac(X,Y):- anh_em_ruot(X,Z), cha(Z,Y).

chau(X,Y):- chu_hoac_bac(Y,X).

father_in_law(X,Y):- cha(X,Z), vo_chong(Z,Y).
% % % % % % % % % % % % % % % % % % % % % % %      
cha(le_khoang,le_tru).

    cha(le_tru,le_khang).

        cha(le_khang,le_tho).

            cha(le_tho,le_duy_thieu).

                cha(le_duy_thieu,le_duy_khoang).

                    cha(le_duy_khoang,le_anh_tong).

                        vua(le_anh_tong).
                        cha(le_anh_tong,le_kinh_tong).

                        vua(le_kinh_tong).
                            cha(le_kinh_tong,le_than_tong).

                            vua(le_than_tong).
                                cha(le_than_tong,le_chan_tong).
                                vua(le_chan_tong).

                                cha(le_than_tong,le_huyen_tong).
                                vua(le_huyen_tong).

                                cha(le_than_tong,le_gia_tong).
                                vua(le_gia_tong).
                            
                                cha(le_than_tong,le_hy_tong).
                                vua(le_hy_tong).
                                    cha(le_hy_tong,le_du_tong).
                                    vua(le_du_tong).
                                        cha(le_du_tong,le_duy_phuong).
                                        vua(le_duy_phuong).
                                        cha(le_du_tong,le_thuan_tong).
                                        vua(le_thuan_tong).
                                            cha(le_thuan_tong,le_hien_tong).
                                            vua(le_hien_tong).
                                                cha(le_hien_tong,le_ngoc_han).
                                                cha(le_hien_tong,le_duy_vi).
                                                    cha(le_duy_vi,le_chieu_thong).
                                                cha(le_hien_tong,le_ngoc_binh).
                                        cha(le_du_tong,le_y_tong).
                                        vua(le_y_tong).
                                
cha(le_khoang,le_thai_to).
    vua(le_thai_to).
    cha(le_thai_to,le_thanh_tong).

        vua(le_thanh_tong).
            cha(le_thanh_tong,le_hien_tong).
            vua(le_hien_tong).

                cha(le_hien_tong,le_tuc_tong).
                    cha(le_hien_tong,le_tuc_tong).
                    vua(le_tuc_tong).
                    cha(le_hien_tong,le_uy_muc).
                    vua(le_uy_muc).

            cha(le_thanh_tong,le_tan).
                cha(le_tan,le_doanh).
                    cha(le_doanh,le_quang_tri).
                cha(le_tan,le_sung).

                    cha(le_sung,le_cung_hoang).
                    cha(le_sung,le_chieu_tong).

                        cha(le_chieu_tong,le_trang_tong).
                        vua(le_trang_tong).

                        cha(le_chieu_tong,le_trung_tong).
                        vua(le_trung_tong).

                    cha(le_tan,le_tuong_duc).
                    vua(le_tuong_duc).

    cha(le_thai_to,le_nhan_tong).
    vua(le_nhan_tong).
    cha(le_thai_to,le_nghi_dan).

%* Trieu Dai Tay Son (tuy khong cung gia pha nha Le nhung Nguyen Hue la con re cua vua Le Hien Tong)
%* Them vo cho hon 50 vi tu thoi =))))
    cha(nguyen_phi_phuc,nguyen_nhac).
    cha(nguyen_phi_phuc,nguyen_hue).
        vua(nguyen_nhac).
        vo_chong(nguyen_hue,le_ngoc_han). %!
        vua(nguyen_hue).%!
            cha(nguyen_hue,nguyen_quang_toan). %! 
            vua(nguyen_quang_toan). %!
