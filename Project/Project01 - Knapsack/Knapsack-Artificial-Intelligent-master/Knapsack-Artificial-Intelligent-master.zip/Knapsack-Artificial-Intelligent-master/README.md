# Knapsack Artificial Intelligent

Solve Knapsack problems using various search algorithms
