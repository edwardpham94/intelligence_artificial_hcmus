from itertools import combinations
import time

# Function to generate CNF clauses for Minesweeper problem
def generate_minesweeper_CNF(matrix):
    CNF = []  # List to store CNF clauses
    rows, cols = len(matrix), len(matrix[0])  # Get matrix dimensions
    added_clauses = []  # List to keep track of added clauses
    un_list = []  # List to store unit clauses for optimization

    # Helper function to get adjacent cells
    def get_neighbors(row, col):
        neighbors = []
        for dr in [-1, 0, 1]:
            for dc in [-1, 0, 1]:
                if dr == 0 and dc == 0:
                    continue
                if (
                    0 <= row + dr < rows
                    and 0 <= col + dc < cols
                    and matrix[row + dr][col + dc] == 0
                ):
                    neighbors.append((row + dr) * cols + col + dc + 1)
        return neighbors

    # Helper function to add a clause to CNF
    def add_clause(clause):
        if clause and clause not in added_clauses:
            CNF.append(clause)
            added_clauses.append(clause)

    # Helper function to check if a '0' cell is safe (no adjacent mines)
    def is_safe(row, col):
        for dr in [-1, 0, 1]:
            for dc in [-1, 0, 1]:
                if dr == 0 and dc == 0:
                    continue
                if 0 <= row + dr < rows and 0 <= col + dc < cols:
                    if matrix[row + dr][col + dc] != 0:
                        return False
        return True

    # Add clue constraints
    for row in range(rows):
        for col in range(cols):
            clue = matrix[row][col]
            if clue > 0:
                CNF.append([-(row * cols + col + 1)])
                un_list.append(-(row * cols + col + 1))
                clue_neighbors = get_neighbors(row, col)
                if clue > len(clue_neighbors):
                    return None
                elif clue == len(clue_neighbors):
                    for cell in clue_neighbors:
                        add_clause([cell])
                        if cell not in un_list:
                            un_list.append(cell)
                else:
                    add_clause(clue_neighbors)
                    for combo in combinations(clue_neighbors, clue + 1):
                        add_clause(list(-x for x in combo))
                    if clue > 1:
                        for combo in combinations(
                            clue_neighbors, len(clue_neighbors) - clue + 1
                        ):
                            add_clause(list(x for x in combo))

            # Add non-mine constraints for uncovered cells
            elif clue == 0 and is_safe(row, col):
                CNF.append([-(row * cols + col + 1)])
                if (-(row * cols + col + 1) not in un_list):
                    un_list.append(-(row * cols + col + 1))

    return CNF,un_list


def solve_cnf_backtracking(clauses, num_vars, unlist):
    def backtrack(assignments, index):
        if index == num_vars:
            return all(eval_clause(clause, assignments) for clause in clauses)

        elif -(index+1) in unlist or index+1 in unlist:
            if backtrack(assignments, index + 1):
                return True

        else:
            for value in [True, False]:
                assignments[index] = value
                if backtrack(assignments, index + 1):
                    return True
                assignments[index] = None

        return False

    def eval_clause(clause, assignments):
        return any(
            (assignments[abs(var) - 1] if var > 0 else not assignments[abs(var) - 1])
            for var in clause
        )

    assignments = [False] * num_vars
    for i in range(len(unlist)):
        x=abs(unlist[i])
        assignments[x-1]=(True if unlist[i]>0 else False)
    if backtrack(assignments, 0):
        return [i + 1 if assignments[i] else -(i + 1) for i in range(num_vars)]
    else:
        return None


# Function to solve Minesweeper using CNF and backtracking
def solve_minesweeper(CNF, matrix, unlist):
    rows, cols = len(matrix), len(matrix[0])
    solution = solve_cnf_backtracking(CNF, rows * cols, unlist)
    if solution != None:
        model = list(solution)
        solved_matrix = [[" " for _ in range(cols)] for _ in range(rows)]
        for lit in model:
            row, col = divmod(abs(lit) - 1, cols)
            if matrix[row][col] != 0:
                solved_matrix[row][col] = matrix[row][col]
            elif lit > 0:
                solved_matrix[row][col] = "X"
            else:
                solved_matrix[row][col] = "0"
        return solved_matrix
    else:
        return None


# Function to read the Minesweeper matrix from a file
def read_matrix_from_file(file_path):
    matrix = []
    with open(file_path, "r") as file:
        for line in file:
            row = list(map(int, line.strip().split()))
            matrix.append(row)
    return matrix


# Function to write the solved matrix to a file
def write_matrix_to_file(file_path, matrix):
    with open(file_path, "w") as file:
        for row in matrix:
            file.write(" ".join(str(cell) for cell in row) + "\n")


if __name__ == "__main__":
    # Input and Output file paths
    input_file_path = "input.txt"
    output_file_path = "output.txt"

    # Read the minesweeper matrix from input file
    input_matrix = read_matrix_from_file(input_file_path)

    # Generate CNF clauses for the Minesweeper problem
    CNF,un_list= generate_minesweeper_CNF(input_matrix)

    # Solve the Minesweeper problem using CNF and backtracking
    start_time = time.time()
    solution = solve_minesweeper(CNF, input_matrix,un_list)
    end_time = time.time()

    # Print the solution or indicate no solution
    if solution:
        print("Solution found:")
        running_time = end_time - start_time
        print(f"Running time of Backtracking Algorithm : {running_time:.6f} seconds")
        write_matrix_to_file(output_file_path, solution)
    else:
        print("No solution")
